-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Creato il: Mag 26, 2020 alle 13:04
-- Versione del server: 5.5.65-MariaDB
-- Versione PHP: 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_aceto`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `tabella_accessi`
--

CREATE TABLE IF NOT EXISTS `tabella_accessi` (
  `utente` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `tabella_accessi`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `tabella_batterie`
--

CREATE TABLE IF NOT EXISTS `tabella_batterie` (
  `ID_batteria` int(10) NOT NULL,
  `nome_batteria` varchar(80) NOT NULL,
  `proprietario` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `tabella_batterie`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `tabella_botti`
--

CREATE TABLE IF NOT EXISTS `tabella_botti` (
  `ID_botti` int(10) NOT NULL,
  `nome_botte` varchar(80) NOT NULL,
  `id_batteria` int(11) NOT NULL,
  `possessore` varchar(80) NOT NULL,
  `differenza_livello_mm` float DEFAULT '0',
  `data_ultima_misura` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `tabella_botti`
--

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `tabella_accessi`
--
ALTER TABLE `tabella_accessi`
  ADD PRIMARY KEY (`utente`);

--
-- Indici per le tabelle `tabella_batterie`
--
ALTER TABLE `tabella_batterie`
  ADD PRIMARY KEY (`ID_batteria`),
  ADD KEY `proprietario` (`proprietario`);

--
-- Indici per le tabelle `tabella_botti`
--
ALTER TABLE `tabella_botti`
  ADD PRIMARY KEY (`ID_botti`),
  ADD KEY `id_batteria` (`id_batteria`),
  ADD KEY `possessore` (`possessore`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `tabella_batterie`
--
ALTER TABLE `tabella_batterie`
  MODIFY `ID_batteria` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT per la tabella `tabella_botti`
--
ALTER TABLE `tabella_botti`
  MODIFY `ID_botti` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=152;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `tabella_batterie`
--
ALTER TABLE `tabella_batterie`
  ADD CONSTRAINT `tabella_batterie_ibfk_1` FOREIGN KEY (`proprietario`) REFERENCES `tabella_accessi` (`utente`);

--
-- Limiti per la tabella `tabella_botti`
--
ALTER TABLE `tabella_botti`
  ADD CONSTRAINT `tabella_botti_ibfk_1` FOREIGN KEY (`id_batteria`) REFERENCES `tabella_batterie` (`ID_batteria`),
  ADD CONSTRAINT `tabella_botti_ibfk_2` FOREIGN KEY (`possessore`) REFERENCES `tabella_accessi` (`utente`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
