package com.example.vero_livellobalsamico_tonicosta;

public class Acetaia{
    private String ID;
    private String Nome_Botte;

    public Acetaia(String ID, String nome_Botte) {
        this.ID = ID;
        this.Nome_Botte = nome_Botte;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNome_Botte() {
        return Nome_Botte;
    }

    public void setNome_Botte(String nome_Botte) {
        Nome_Botte = nome_Botte;
    }

    @Override
    public String toString() {
        return "Acetaia{" +
                "ID='" + ID + '\'' +
                ", Nome_Botte='" + Nome_Botte + '\'' +
                '}';
    }
}
