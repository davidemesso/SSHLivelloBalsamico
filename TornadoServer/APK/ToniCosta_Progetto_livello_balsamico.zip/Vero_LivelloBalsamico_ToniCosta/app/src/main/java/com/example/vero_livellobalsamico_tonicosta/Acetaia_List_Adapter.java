package com.example.vero_livellobalsamico_tonicosta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Acetaia_List_Adapter extends ArrayAdapter<Acetaia> {
    private static final String TAG= "AcetaiaListAdapter";

    private Context mContext;
    int mResource;
    ArrayList<Acetaia> mObject;


    public Acetaia_List_Adapter(@NonNull Context context, int resource, @NonNull ArrayList<Acetaia> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource= resource;
        mObject= objects;
    }

    public void updateReceiptsList(ArrayList<Acetaia> newlist) {
        mObject.clear();
        mObject.addAll(newlist);
        this.notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String id=getItem(position).getID();
        String nome_batteria=getItem(position).getNome_Botte();

        Acetaia aceto=new Acetaia(id,nome_batteria);

        LayoutInflater inflater= LayoutInflater.from(mContext);
        convertView=inflater.inflate(mResource, parent, false);

        TextView idio= (TextView) convertView.findViewById(R.id.textViewVISACETAIA);
        TextView nomeio= (TextView) convertView.findViewById(R.id.textView2VISACETAIA);

        idio.setText(id);
        nomeio.setText(nome_batteria);

        return convertView;
    }
}
