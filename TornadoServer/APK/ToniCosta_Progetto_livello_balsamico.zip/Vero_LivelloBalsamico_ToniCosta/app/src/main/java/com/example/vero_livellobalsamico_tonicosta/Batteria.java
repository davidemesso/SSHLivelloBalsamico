package com.example.vero_livellobalsamico_tonicosta;

public class Batteria {
    String ID;
    String Nome_Botte;
    String Differennza_Livello;
    String Data;

    public Batteria(String ID, String nome_Botte, String differennza_Livello, String data) {
        this.ID = ID;
        this.Nome_Botte = nome_Botte;
        this.Differennza_Livello = differennza_Livello;
        this.Data=data;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNome_Botte() {
        return Nome_Botte;
    }

    public void setNome_Botte(String nome_Botte) {
        Nome_Botte = nome_Botte;
    }

    public String getDifferennza_Livello() {
        return Differennza_Livello;
    }

    public void setDifferennza_Livello(String differennza_Livello) {
        Differennza_Livello = differennza_Livello;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    @Override
    public String toString() {
        return "Batteria{" +
                "ID='" + ID + '\'' +
                ", Nome_Botte='" + Nome_Botte + '\'' +
                ", Differennza_Livello='" + Differennza_Livello + '\'' + ", Data='" + Data+ '\''+ "'"  +'}';
    }
}
