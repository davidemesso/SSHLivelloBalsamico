package com.example.vero_livellobalsamico_tonicosta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
public class Batteria_List_Adapter extends ArrayAdapter<Batteria>{
    private static final String TAG= "BatteriaListAdapter";

    private Context mContext;
    int mResource;
    ArrayList<Batteria> mObject;


    public Batteria_List_Adapter(@NonNull Context context, int resource, @NonNull ArrayList<Batteria> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource= resource;
        mObject= objects;
    }

    public void updateReceiptsList(ArrayList<Batteria> newlist) {
        mObject.clear();
        mObject.addAll(newlist);
        this.notifyDataSetChanged();
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String id = getItem(position).getID();
        String nome_botte = getItem(position).getNome_Botte();
        String diff_livello= getItem(position).getDifferennza_Livello();
        String data=getItem(position).getData();

        Batteria batteria=new Batteria(id,nome_botte,diff_livello,data);

        LayoutInflater inflater= LayoutInflater.from(mContext);
        convertView=inflater.inflate(mResource, parent, false);

        TextView idio= (TextView) convertView.findViewById(R.id.textViewVISBATTERIA);
        TextView nomeio= (TextView) convertView.findViewById(R.id.textView2VISBATTERIA);
        TextView omiodio= (TextView) convertView.findViewById(R.id.textView3VISBATTERIA);
        TextView manonio=(TextView) convertView.findViewById(R.id.textView4VISBATTERIA);

        idio.setText(id);
        nomeio.setText(nome_botte);
        omiodio.setText(diff_livello);
        manonio.setText(data);

        return convertView;
    }
}
