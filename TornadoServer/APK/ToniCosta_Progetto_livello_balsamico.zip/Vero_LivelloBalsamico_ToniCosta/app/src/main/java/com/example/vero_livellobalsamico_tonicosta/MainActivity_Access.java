package com.example.vero_livellobalsamico_tonicosta;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_Access extends AppCompatActivity {
    TextView incase;
    EditText usr, psw;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_access);
        incase=(TextView) findViewById(R.id.forreal);
        usr= (EditText) findViewById(R.id.usernameACCESS);
        psw= (EditText) findViewById(R.id.passwordACCESS);

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintACCESS);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        LinearLayout linearLayout = findViewById(R.id.Linearacc);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();
    }
    public void loginBtn(View view) {
        Send objSend = new Send();
        objSend.execute("");

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity.class);

            startActivity(miaActivity);
            finish();

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private class Send extends AsyncTask<String, String, String> {
        String msg = "";
        String user = usr.getText().toString();
        String password = psw.getText().toString();
        List<String> listautenti = new ArrayList<String>(100);
        List<String> listapassword = new ArrayList<String>(100);
        List<String> listabatterie = new ArrayList<String>(100);
        List<String> listabotte = new ArrayList<String>(100);

        @Override
        protected void onPreExecute() {
            incase.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                if (user.isEmpty()) {
                    msg = "inserisci il nome utente...";
                    return msg;
                }
                if (password.isEmpty()) {
                    msg = "inserisci la password...";
                    return msg;
                }
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {
                    user=user.toLowerCase();
                    String SELECT = "SELECT * FROM tabella_accessi";
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECT);

                    int n=0;
                    int i=0;
                    for(i=listautenti.size()-1;i>=0;i--) {
                        listautenti.remove(i);
                    }
                    for(i=listapassword.size()-1;i>=0;i--) {
                        listapassword.remove(i);
                    }
                    while(rs.next()){
                        listautenti.add(n,rs.getString(1));
                        listapassword.add(n,rs.getString(2));
                        n++;
                    }
                    int j;
                    for(j=0;j<listautenti.size();j++){
                        if(user.equals(listautenti.get(j))){
                            msg = "controllo password...";
                            if(password.equals(listapassword.get(j))){
                                msg="accesso in corso...";
                                String SELECTbatterie = "SELECT * FROM tabella_batterie WHERE proprietario='"+user+"'";
                                String SELECTbotti = "SELECT * FROM tabella_botti WHERE possessore='"+user+"'";

                                ResultSet res= stmt.executeQuery(SELECTbatterie);


                                n=0;
                                int m=0;
                                for(i=listabatterie.size()-1;i>=0;i--) {
                                    listabatterie.remove(i);
                                }
                                for(i=listabotte.size()-1;i>=0;i--) {
                                    listabotte.remove(i);
                                }

                                while(res.next()){
                                    listabatterie.add(n,res.getString(2));
                                    n++;
                                }

                                res.close();

                                ResultSet erres=stmt.executeQuery(SELECTbotti);
                                while(erres.next()){
                                    listabotte.add(m,erres.getString(2));
                                    m++;
                                }
                                erres.close();

                                int flagBatterie=0;
                                int flagBotti=0;
                                if(listabatterie.isEmpty()){
                                    flagBatterie=1;
                                }
                                else{
                                    if(listabotte.isEmpty()){
                                        flagBotti=1;
                                    }
                                }

                                Intent pagina_indatabase = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
                                pagina_indatabase.putExtra("user",user);
                                pagina_indatabase.putExtra("flbat",flagBatterie);
                                pagina_indatabase.putExtra("flbot",flagBotti);
                                pagina_indatabase.putExtra("msg","Accesso eseguito!");

                                startActivity(pagina_indatabase);

                                finish();
                                return msg;
                            }
                            else{
                                msg= "password errata...";
                                return msg;
                            }

                        }

                    }
                    msg="username errato...";
                    return msg;
                }
                conn.close();
            }
            catch (Exception e){

                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incase.setText(msg);
        }
    }

}