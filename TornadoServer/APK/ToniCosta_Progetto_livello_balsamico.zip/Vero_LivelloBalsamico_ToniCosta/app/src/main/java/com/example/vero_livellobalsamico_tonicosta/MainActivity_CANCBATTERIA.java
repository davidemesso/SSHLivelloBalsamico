package com.example.vero_livellobalsamico_tonicosta;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_CANCBATTERIA extends AppCompatActivity implements android.widget.AdapterView.OnItemSelectedListener{
    String userino;
    TextView incaso,indb;
    Spinner batteria;
    Spin_String str;
    Spinner_Adapter aa;
    Controllospinner controllo;
    ArrayList<Spin_String> LISTAbatterie;
    AlertDialog.Builder alertBat;
    int flagBatteria,flagBotte;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__cancbatteri);
        incaso=(TextView) findViewById(R.id.controlloCANC);
        indb=(TextView) findViewById(R.id.textviewESEGUITO);
        batteria=(Spinner) findViewById(R.id.CancBatteria);
        userino = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");

        alertBat= new AlertDialog.Builder(this);
        alertBat.setTitle("ATTENZIONE!");
        alertBat.setMessage("Una volta cancellata la batteria verranno cancellate anche le botti al suo interno! \ncontinuare?");
        alertBat.setPositiveButton("SÌ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Send objSend = new Send();
                objSend.execute("");
            }
        });
        alertBat.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintCANCBATTERIA);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();


        LinearLayout linearLayout = findViewById(R.id.Linearcancbat);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();


        LISTAbatterie= new ArrayList<>();
        System.out.println(LISTAbatterie.toString());
        aa = new Spinner_Adapter(this,LISTAbatterie);

        batteria.setOnItemSelectedListener(this);

        controllo= new Controllospinner();
        controllo.execute("");

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_MODBATTERIA.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);

            startActivity(miaActivity);
            finish();

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void CancBtn(View view) {
        alertBat.create().show();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        str= (Spin_String)parent.getSelectedItem();
        Toast.makeText(this,str.getBotte_batteria(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class Send extends AsyncTask<String, String, String> {
        String msg = "";
        String battery = str.toString();
        Controllospinner control= new Controllospinner();
        List<String> listabatterie = new ArrayList<String>(100);
        List<String> listabotti = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                if (battery.isEmpty()) {
                    msg = "prima inserire batteria...";
                    return msg;
                }
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {

                    String DELETEbotti = "DELETE FROM tabella_botti WHERE id_batteria=(SELECT ID_batteria FROM tabella_batterie WHERE proprietario='" +userino+ "' AND nome_batteria='" +battery+ "')";
                    String SELECTbatterie = "SELECT * FROM tabella_batterie WHERE proprietario='"+userino+"'";
                    String SELECTbotti= "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";
                    String DELETEbatterie = "DELETE FROM tabella_batterie WHERE proprietario='"+userino+"' AND nome_batteria='"+battery+"'";
                    Statement stmt = conn.createStatement();
                    ResultSet rosica= stmt.executeQuery(SELECTbatterie);

                    System.out.println(SELECTbatterie);
                    System.out.println(SELECTbotti);
                    int n=0;
                    int i;
                    for(i=listabatterie.size()-1;i>=0;i--) {
                        listabatterie.remove(i);
                    }
                    System.out.println(listabatterie);
                    while(rosica.next()){
                        listabatterie.add(n,rosica.getString(2));
                        System.out.println(listabatterie);
                        n++;
                    }
                    rosica.close();
                    System.out.println(listabatterie);
                    int flag=0;
                    for(i=0;i<listabatterie.size();i++){
                        if(battery.equals(listabatterie.get(i))){
                            flag=1;
                        }
                    }
                    if(flag==1) {
                        stmt.executeUpdate(DELETEbotti);
                        stmt.executeUpdate(DELETEbatterie);
                        ResultSet erres= stmt.executeQuery(SELECTbatterie);
                        msg="la batteria è stata cancellata";

                        for(i=listabatterie.size()-1;i>=0;i--) {
                            listabatterie.remove(i);
                        }
                        n=0;
                        while(erres.next()){
                            listabatterie.add(n,erres.getString(2));
                            n++;
                        }
                        erres.close();
                        for(i=listabotti.size()-1;i>=0;i--) {
                            listabotti.remove(i);
                        }
                        n=0;
                        ResultSet resa = stmt.executeQuery(SELECTbotti);
                        while(resa.next()){
                            listabotti.add(n,resa.getString(2));
                            n++;
                        }
                        resa.close();


                        return msg;
                    }
                    msg="batteria inestistente";
                }
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            if(listabatterie.isEmpty()){
                flagBatteria=1;
            }
            if (listabotti.isEmpty()){
                flagBotte=1;
            }


            incaso.setText(msg);
            Toast.makeText(MainActivity_CANCBATTERIA.this,msg, Toast.LENGTH_SHORT).show();
            control.execute("");
        }
    }

    public class Controllospinner extends AsyncTask<String, String, String> {
        String msg ="";
        List<String> listabatteria = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else{
                    String SELECTbatterie = "SELECT * FROM tabella_batterie WHERE proprietario='"+userino+"'";
                    System.out.println(SELECTbatterie);
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECTbatterie);
                    int n=0;
                    int i=0;
                    for(i=listabatteria.size()-1;i>=0;i--) {
                        listabatteria.remove(i);
                    }
                    while(rs.next()){
                        listabatteria.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();
                    System.out.println(Arrays.toString(listabatteria.toArray()));
                    for(i=LISTAbatterie.size()-1;i>=0;i--){
                        System.out.println(Arrays.toString(LISTAbatterie.toArray()));
                        LISTAbatterie.remove(i);
                    }
                    for(i=0;i<listabatteria.size();i++){
                        Spin_String obj = new Spin_String(listabatteria.get(i));
                        System.out.println(Arrays.toString(listabatteria.toArray()));
                        LISTAbatterie.add(obj);
                    }
                }
                System.out.println(LISTAbatterie.toString());
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            if(msg.equals("")){
            incaso.setText("in attesa...");
            }
            else{
                incaso.setText(msg);
            }
            batteria.setAdapter(aa);
        }
    }

}

