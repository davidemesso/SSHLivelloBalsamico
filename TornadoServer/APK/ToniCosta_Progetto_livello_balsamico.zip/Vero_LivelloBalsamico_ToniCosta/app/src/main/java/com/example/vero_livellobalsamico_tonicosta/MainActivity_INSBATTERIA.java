package com.example.vero_livellobalsamico_tonicosta;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_INSBATTERIA extends AppCompatActivity {
    String userino,occhio="";
    TextView incaso;
    EditText batteria;
    int flagBatteria,flagBotte;
    AlertDialog.Builder alertBat,alertBot;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_insbatteria);
        incaso=(TextView) findViewById(R.id.controlloINS);
        batteria=(EditText) findViewById(R.id.InsBatteria);
        userino = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintINSBATTERIA);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        alertBat= new AlertDialog.Builder(this);
        alertBat.setTitle("ATTENZIONE!");
        alertBat.setMessage("Il nome della batteria esiste già, prego inserire un nome diverso.");
        alertBat.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                incaso.setText("");
            }
        });

        alertBot= new AlertDialog.Builder(this);
        alertBot.setTitle("ATTENZIONE!");
        alertBot.setMessage("Inserisci il nome della batteria prima di cliccare sul bottone!");
        alertBot.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                incaso.setText("");
            }
        });

        LinearLayout linearLayout = findViewById(R.id.Linearinsbat);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);
            miaActivity.putExtra("msg",occhio);

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void InsBtn(View view) {
        Send objSend = new Send();
        objSend.execute("");

    }

    public class Send extends AsyncTask<String, String, String> {
        String msg = "";
        int flag=0;
        String battery = batteria.getText().toString();
        List<String> listabatterie = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                if (battery.isEmpty()) {
                    flag=2;

                    return msg;
                }
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {
                    battery=battery.toLowerCase();
                    String INSERT = "INSERT INTO tabella_batterie(nome_batteria,proprietario) VALUES('" + battery + "','" + userino + "')";
                    String SELECT = "SELECT * FROM tabella_batterie where proprietario='"+userino+"'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECT);

                    int n=0;
                    int i=0;
                    for(i=listabatterie.size()-1;i>=0;i--) {
                        listabatterie.remove(i);
                    }
                    while(rs.next()){
                        listabatterie.add(n,rs.getString(2));
                        n++;
                    }

                    for(i=0;i<listabatterie.size();i++){
                        if(battery.equals(listabatterie.get(i))){
                            flag=1;
                            return msg;
                        }
                    }
                    stmt.executeUpdate(INSERT);
                    msg = "Batteria inserita!!";
                    flagBatteria=0;
                    occhio = "Batteria inserita!!";
                }
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incaso.setText(msg);
            batteria.setText("");
            if (flag==1){
                alertBat.create().show();
            }
            else if(flag==2){
                alertBot.create().show();
            }
        }
    }

}
