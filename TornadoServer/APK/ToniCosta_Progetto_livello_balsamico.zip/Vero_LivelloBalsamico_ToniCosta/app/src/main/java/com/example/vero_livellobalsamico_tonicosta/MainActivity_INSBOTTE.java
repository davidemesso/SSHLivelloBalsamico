package com.example.vero_livellobalsamico_tonicosta;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class MainActivity_INSBOTTE extends AppCompatActivity implements android.widget.AdapterView.OnItemSelectedListener{
    Spin_String str;
    String userino,occhio="";
    TextView incaso;
    EditText botte;
    Spinner scelta;
    Spinner_Adapter aa;
    ArrayList<Spin_String> LISTAbatterie;
    int flagBatteria,flagBotte;
    AlertDialog.Builder alertBat,alertBot;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_insbotte);
        incaso=(TextView) findViewById(R.id.controlloINSbotte);
        scelta=(Spinner) findViewById(R.id.SpinInsBotte);
        botte=(EditText) findViewById(R.id.InsBotte);
        userino = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");
        LISTAbatterie= new ArrayList<>();

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintINSBOTTE);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        LinearLayout linearLayout = findViewById(R.id.Linearinsbot);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        alertBat= new AlertDialog.Builder(this);
        alertBat.setTitle("ATTENZIONE!");
        alertBat.setMessage("Il nome della botte esiste già, prego inserire un nome diverso.");
        alertBat.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                incaso.setText("");
            }
        });

        alertBot= new AlertDialog.Builder(this);
        alertBot.setTitle("ATTENZIONE!");
        alertBot.setMessage("Inserisci il nome della botte prima di cliccare sul bottone!");
        alertBot.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                incaso.setText("");
            }
        });

        aa = new Spinner_Adapter(this,LISTAbatterie);

            scelta.setOnItemSelectedListener(this);

        Controllospinner controllo= new Controllospinner();
        controllo.execute("");
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);
            miaActivity.putExtra("msg",occhio);

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void BotBtn(View view) {
        Send objSend = new Send();
        objSend.execute("");


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        str= (Spin_String)parent.getSelectedItem();
        Toast.makeText(this,str.getBotte_batteria(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class Send extends AsyncTask<String, String, String> {
        String msg = "";
        int flaggo=0;
        String battery = str.toString();
        String barrel = botte.getText().toString();
        List<String> listabatterie = new ArrayList<String>(100);
        List<String> listabotte = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                System.out.println(battery);

                if (barrel.isEmpty()) {
                    flaggo=2;
                    msg = "prima inserire botte...";
                    return msg;
                }

                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {
                    String pattern = "yyyy-MM-dd";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

                    String date = simpleDateFormat.format(new Date());

                    barrel=barrel.toLowerCase();
                    String INSERT = "INSERT INTO tabella_botti(nome_botte,id_batteria,possessore,data_ultima_misura) VALUES('" + barrel + "',(SELECT ID_batteria FROM tabella_batterie WHERE proprietario='" +userino+ "' AND nome_batteria='" +battery+ "'),'" + userino + "','"+ date +"')";
                    String SELECTbatterie = "SELECT * FROM tabella_batterie WHERE proprietario='"+userino+"'";
                    String SELECTbotti = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";
                    System.out.println(SELECTbatterie);
                    Statement stmt = conn.createStatement();
                    System.out.println(SELECTbotti);
                    ResultSet rs= stmt.executeQuery(SELECTbatterie);
                    System.out.println(INSERT);
                    int n=0;
                    int m=0;
                    int i=0;
                    for(i=listabatterie.size()-1;i>=0;i--) {
                        listabatterie.remove(i);
                    }
                    for(i=listabotte.size()-1;i>=0;i--) {
                        listabotte.remove(i);
                    }
                    while(rs.next()){
                        listabatterie.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();
                    ResultSet erres=stmt.executeQuery(SELECTbotti);
                    while(erres.next()){
                        listabotte.add(m,erres.getString(2));
                        m++;
                    }
                    rs.close();
                    int flag=0;
                    for(i=0;i<listabatterie.size();i++){
                        if(battery.equals(listabatterie.get(i))){
                            flag=1;
                            for(n=0;n<listabotte.size();n++){
                                if(barrel.equals(listabotte.get(n))){
                                    flaggo=1;
                                    msg="nome botte già utilizzato, provare uno diverso";
                                    return msg;
                                }

                                }
                            }
                        }
                    if(flag==1) {
                        stmt.executeUpdate(INSERT);
                        msg = "Botte inserita!!";
                        flagBotte=0;
                        occhio = "Botte inserita!!";
                    }
                    else{
                        msg="nessuna batteria trovata con questo nome...";
                        return msg;
                    }
                }
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incaso.setText(msg);
            botte.setText("");
            if (flaggo==1){
                alertBat.create().show();
            }
            else if(flaggo==2){
                alertBot.create().show();
            }
        }
    }
    public class Controllospinner extends AsyncTask<String, String, String> {
        String msg = "";
        List<String> listabatteria = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else{
                    String SELECTbatterie = "SELECT * FROM tabella_batterie WHERE proprietario='"+userino+"'";
                    System.out.println(SELECTbatterie);
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECTbatterie);
                    int n=0;
                    int i=0;
                    for(i=listabatteria.size()-1;i>=0;i--) {
                        listabatteria.remove(i);
                    }
                    while(rs.next()){
                        listabatteria.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();
                    System.out.println(Arrays.toString(listabatteria.toArray()));
                    for(i=0;i<listabatteria.size();i++){
                        Spin_String obj = new Spin_String(listabatteria.get(i));
                        LISTAbatterie.add(obj);
                        }
                }
                System.out.println(LISTAbatterie.toString());
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incaso.setText(msg);
            scelta.setAdapter(aa);
        }
    }
}