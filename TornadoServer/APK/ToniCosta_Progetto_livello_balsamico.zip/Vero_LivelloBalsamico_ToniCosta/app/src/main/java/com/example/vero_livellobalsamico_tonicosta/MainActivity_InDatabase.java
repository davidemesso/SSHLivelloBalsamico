package com.example.vero_livellobalsamico_tonicosta;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.view.MenuItem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity_InDatabase extends AppCompatActivity {
    String username, message;
    int flagBatteria;
    int flagBotte;
    TextView mes;
    AlertDialog.Builder alertBat;
    AlertDialog.Builder alertBot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_in_database);
        username = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");
        message = getIntent().getExtras().getString("msg");
        mes=(TextView) findViewById(R.id.textviewESEGUITO);
        System.out.println(flagBatteria);
        System.out.println(flagBotte);
        mes.setText(message);

        alertBat= new AlertDialog.Builder(this);
        alertBat.setTitle("ATTENZIONE!");
        alertBat.setMessage("prima di qualsiasi altra cosa devi inserire almeno una batteria!");
        alertBat.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent pagina_Insbatteria = new Intent(getApplicationContext(), MainActivity_INSBATTERIA.class);
                pagina_Insbatteria.putExtra("user",username);
                pagina_Insbatteria.putExtra("flbat",flagBatteria);
                pagina_Insbatteria.putExtra("flbot",flagBotte);
                finish();
                startActivity(pagina_Insbatteria);
            }
        });

        alertBot= new AlertDialog.Builder(this);
        alertBot.setTitle("ATTENZIONE!");
        alertBot.setMessage("devi inserire almeno una botte se vuoi continuare!");
        alertBot.setNeutralButton("CAPITO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent pagina_Insbotte = new Intent(getApplicationContext(), MainActivity_INSBOTTE.class);
                pagina_Insbotte.putExtra("user", username);
                pagina_Insbotte.putExtra("flbat",flagBatteria);
                pagina_Insbotte.putExtra("flbot",flagBotte);
                finish();
                startActivity(pagina_Insbotte);
            }
        });

        Button INSbatteria = (Button) findViewById(R.id.buttonINSBATTERIA);
        INSbatteria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent pagina_Insbatteria = new Intent(getApplicationContext(), MainActivity_INSBATTERIA.class);
                pagina_Insbatteria.putExtra("user",username);
                pagina_Insbatteria.putExtra("flbat",flagBatteria);
                pagina_Insbatteria.putExtra("flbot",flagBotte);
                finish();
                startActivity(pagina_Insbatteria);
            }
        });
    }
    public void InInsBtn(View view){
        if(flagBatteria==0) {
            Intent pagina_Insbotte = new Intent(getApplicationContext(), MainActivity_INSBOTTE.class);
            pagina_Insbotte.putExtra("user", username);
            pagina_Insbotte.putExtra("flbat",flagBatteria);
            pagina_Insbotte.putExtra("flbot",flagBotte);
            finish();
            startActivity(pagina_Insbotte);
        }
        else{
            alertBat.create().show();
        }
    }

    public void InModBatBtn(View view){
        if(flagBatteria==0) {
            Intent pagina_Modbatteria = new Intent(getApplicationContext(), MainActivity_MODBATTERIA.class);
            pagina_Modbatteria.putExtra("user", username);
            pagina_Modbatteria.putExtra("flbat",flagBatteria);
            pagina_Modbatteria.putExtra("flbot",flagBotte);
            finish();
            startActivity(pagina_Modbatteria);
        }
        else{
            alertBat.create().show();
        }
    }

    public void InModBotBtn(View view){
        if(flagBatteria==0){
            if(flagBotte==0) {
                Intent pagina_Modbotte = new Intent(getApplicationContext(), MainActivity_MODBOTTE.class);
                pagina_Modbotte.putExtra("user", username);
                pagina_Modbotte.putExtra("flbat",flagBatteria);
                pagina_Modbotte.putExtra("flbot",flagBotte);
                finish();
                startActivity(pagina_Modbotte);
            }
            else{
                alertBot.create().show();
            }
        }
        else{
            alertBat.create().show();
        }
    }

    public void InVisAceBtn(View view){
        if(flagBatteria==0){
        Intent pagina_Visacetaia = new Intent(getApplicationContext(), MainActivity_VISACETAIA.class);
        pagina_Visacetaia.putExtra("user",username);
            pagina_Visacetaia.putExtra("flbat",flagBatteria);
            pagina_Visacetaia.putExtra("flbot",flagBotte);
            finish();
        startActivity(pagina_Visacetaia);
        }
        else{
            alertBat.create().show();
        }
    }

    public void InVisBatBtn(View view){
        if(flagBatteria==0){
            if(flagBotte==0) {
        Intent pagina_Visbatteria = new Intent(getApplicationContext(), MainActivity_VISBATTERIA.class);
        pagina_Visbatteria.putExtra("user",username);
        pagina_Visbatteria.putExtra("flbat",flagBatteria);
        pagina_Visbatteria.putExtra("flbot",flagBotte);
                finish();
        startActivity(pagina_Visbatteria);
            }
            else{
                alertBot.create().show();
            }
        }
        else{
            alertBat.create().show();
        }
    }

    public void InOttBtn(View view){
        if(flagBatteria==0){
            if(flagBotte==0) {
        Intent pagina_Ottmisurazione = new Intent(getApplicationContext(), MainActivity_OTTMISURAZIONE.class);
        pagina_Ottmisurazione.putExtra("user",username);
        pagina_Ottmisurazione.putExtra("flbat",flagBatteria);
        pagina_Ottmisurazione.putExtra("flbot",flagBotte);
                finish();
        startActivity(pagina_Ottmisurazione);
            }
            else{
                alertBot.create().show();
            }
        }
        else{
            alertBat.create().show();
        }
    }

    public void InResBtn(View view){
        if(flagBatteria==0){
            if(flagBotte==0) {
        Intent pagina_Resmisurazione = new Intent(getApplicationContext(), MainActivity_RESMISURAZIONE.class);
        pagina_Resmisurazione.putExtra("user",username);
        pagina_Resmisurazione.putExtra("flbat",flagBatteria);
        pagina_Resmisurazione.putExtra("flbot",flagBotte);
                finish();
        startActivity(pagina_Resmisurazione);
            }
            else{
                alertBot.create().show();
            }
        }
        else{
            alertBat.create().show();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity.class);
            finish();
            startActivity(miaActivity);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
