package com.example.vero_livellobalsamico_tonicosta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.view.MenuItem;

public class MainActivity_MODBATTERIA extends AppCompatActivity {
    int flagBatteria,flagBotte;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_modbatteria);
        username = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");
        Button CANCbatteria = (Button) findViewById(R.id.buttonCANCBATTERIA);

        CANCbatteria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pagina_Cancbatteria = new Intent(getApplicationContext(), MainActivity_CANCBATTERIA.class);
                pagina_Cancbatteria.putExtra("user",username);
                pagina_Cancbatteria.putExtra("flbat", flagBatteria);
                pagina_Cancbatteria.putExtra("flbot", flagBotte);
                startActivity(pagina_Cancbatteria);
                finish();
            }
        });

        Button RINbatteria = (Button) findViewById(R.id.buttonRINBATTERIA);
        RINbatteria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pagina_Rinbatteria = new Intent(getApplicationContext(), MainActivity_RINBATTERIA.class);
                pagina_Rinbatteria.putExtra("user",username);
                pagina_Rinbatteria.putExtra("flbat", flagBatteria);
                pagina_Rinbatteria.putExtra("flbot", flagBotte);

                startActivity(pagina_Rinbatteria);
                finish();
            }
        });
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", username);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);
            miaActivity.putExtra("msg", "");

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
