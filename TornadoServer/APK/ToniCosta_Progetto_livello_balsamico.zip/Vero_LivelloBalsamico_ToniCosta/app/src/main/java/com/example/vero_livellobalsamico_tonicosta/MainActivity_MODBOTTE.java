package com.example.vero_livellobalsamico_tonicosta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.view.MenuItem;

public class MainActivity_MODBOTTE extends AppCompatActivity {
    String username;
    int flagBatteria, flagBotte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__modbotte);
        username = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");
        Button CANCbotte = (Button) findViewById(R.id.buttonCANCBOTTE);

        CANCbotte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pagina_Cancbotte = new Intent(getApplicationContext(), MainActivity_CANCBOTTE.class);
                pagina_Cancbotte.putExtra("user", username);
                pagina_Cancbotte.putExtra("flbat", flagBatteria);
                pagina_Cancbotte.putExtra("flbot", flagBotte);

                startActivity(pagina_Cancbotte);

                finish();
            }
        });

        Button RINbotte = (Button) findViewById(R.id.buttonRINBOTTE);
        RINbotte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pagina_Rinbotte = new Intent(getApplicationContext(), MainActivity_RINBOTTE.class);
                pagina_Rinbotte.putExtra("user", username);
                pagina_Rinbotte.putExtra("flbat", flagBatteria);
                pagina_Rinbotte.putExtra("flbot", flagBotte);

                startActivity(pagina_Rinbotte);

                finish();
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", username);
            miaActivity.putExtra("flbot", flagBotte);
            miaActivity.putExtra("flbat", flagBatteria);
            miaActivity.putExtra("msg", "");

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}