package com.example.vero_livellobalsamico_tonicosta;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_OTTMISURAZIONE extends AppCompatActivity implements android.widget.AdapterView.OnItemSelectedListener{
    String userino,occhio="";
    TextView incaso;
    Spinner botte;
    String batteria;
    int FLAG=1;
    Spin_String str;
    Spinner_Adapter aa;
    ArrayList<Spin_String> LISTAbatterie;
    MqttClient client;
    int flagBatteria,flagBotte, FlagError=0;
    MqttConnectOptions options;

    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__ottmisurazione);
        incaso=(TextView) findViewById(R.id.controlloOTT);
        botte=(Spinner) findViewById(R.id.OttBotte);
        userino = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");

        LISTAbatterie= new ArrayList<>();
        System.out.println(LISTAbatterie.toString());
        aa = new Spinner_Adapter(this,LISTAbatterie);

        botte.setOnItemSelectedListener(this);

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintOTTMIS);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        LinearLayout linearLayout = findViewById(R.id.Linearottmis);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        Controllospinner controllo= new Controllospinner();
        controllo.execute("");
        try {
            String serverUrl = "ssl://balsamico.toni.it:8883";
            String clientId = MqttClient.generateClientId();
            client = new MqttClient(serverUrl, clientId , null);
            options = new MqttConnectOptions();
            options.setConnectionTimeout(60);
            options.setKeepAliveInterval(60);
            options.setSocketFactory(SslUtil.getSocketFactory(getResources().getString(R.string.ca_crt), getResources().getString(R.string.client_crt), getResources().getString(R.string.client_key), ""));
            incaso.setText("SEI CONNESSO!!");
        } catch (MqttException e) {
            incaso.setText("ERRORE CON MQTT!!");
            e.printStackTrace();
        } catch (Exception e) {
            incaso.setText("ERRORE!!");
            e.printStackTrace();
        }
    }


    public void OttBtn(View view) {
        Send objSend = new Send();
        objSend.execute("");

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);
            miaActivity.putExtra("msg", occhio);

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        str= (Spin_String)parent.getSelectedItem();
        Toast.makeText(this,str.getBotte_batteria(), Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class Send extends AsyncTask<String, String, String> {
        String msg = "";
        String barrel = str.toString();
        List<String> listabotte = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                if (barrel.isEmpty()) {
                    msg = "prima inserire botte...";
                    return msg;
                }
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {
                    String SELECT = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECT);

                    int n=0;
                    int i=0;
                    for(i=listabotte.size()-1;i>=0;i--) {
                        listabotte.remove(i);
                    }
                    while(rs.next()){
                        listabotte.add(n,rs.getString(2));
                        n++;
                    }

                    for(i=0;i<listabotte.size();i++){
                        if(barrel.equals(listabotte.get(i))){
                            client.connect(options);
                            String topic = "inviodati";
                            String payload = "'"+userino+"','"+barrel+"'";
                            byte[] encodedPayload = new byte[0];
                            try {
                                encodedPayload = payload.getBytes("UTF-8");
                                MqttMessage message = new MqttMessage(encodedPayload);
                                message.setRetained(true);
                                client.publish(topic, message);
                                msg="Misurazione effettuata!!";
                                occhio="Misurazione effettuata!!";
                                client.disconnect();

                                String SELECTBAT = "SELECT nome_batteria FROM tabella_batterie WHERE ID_batteria = (SELECT id_batteria FROM tabella_botti WHERE possessore='" +userino+ "' AND nome_botte='" +barrel+ "')";
                                ResultSet ress= stmt.executeQuery(SELECTBAT);

                                while(ress.next()){
                                    batteria=ress.getString(1);
                                }
                                rs.close();
                                Intent miaActivity = new Intent(getApplicationContext(), MainActivity_VERAVISBATTERIA.class);
                                miaActivity.putExtra("user", userino);
                                miaActivity.putExtra("flbot",flagBotte);
                                miaActivity.putExtra("flbat",flagBatteria);
                                miaActivity.putExtra("bat",batteria);
                                miaActivity.putExtra("flag", FLAG);

                                startActivity(miaActivity);
                                finish();
                                conn.close();
                            } catch (UnsupportedEncodingException | MqttException e) {
                                FlagError=1;
                                e.printStackTrace();
                            }
                            return msg;
                        }
                    }
                    msg="botte inesistente";

                    return msg;
                }
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            if(FlagError==1){
                incaso.setText("IMPOSSIBILE OPERARE!!");
            }
            else{
                incaso.setText(msg);
            }
        }
    }

    public class Controllospinner extends AsyncTask<String, String, String> {
        String msg = "";
        List<String> listabatteria = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else{
                    String SELECTbatterie = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";

                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECTbatterie);
                    int n=0;
                    int i=0;
                    for(i=listabatteria.size()-1;i>=0;i--) {
                        listabatteria.remove(i);
                    }
                    while(rs.next()){
                        listabatteria.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();

                    for(i=0;i<listabatteria.size();i++){
                        Spin_String obj = new Spin_String(listabatteria.get(i));
                        LISTAbatterie.add(obj);
                    }
                }

                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            if(msg.equals("")) {

            }
            else{
                incaso.setText("msg");
            }
            botte.setAdapter(aa);
        }
    }

}
