package com.example.vero_livellobalsamico_tonicosta;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_RINBOTTE extends AppCompatActivity implements android.widget.AdapterView.OnItemSelectedListener{
    String userino;
    TextView incaso;
    EditText rin;
    Spinner nonrin;
    Spinner_Adapter aa;
    ArrayList<Spin_String> LISTAbatterie;
    Spin_String str;
    int flagBatteria,flagBotte;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__rinbotte);
        incaso=(TextView) findViewById(R.id.controlloRINbotte);
        nonrin= (Spinner) findViewById(R.id.NonRinbotte);
        rin= (EditText) findViewById(R.id.Rinbotte);
        userino = getIntent().getExtras().getString("user");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintRINBOTTE);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        LinearLayout linearLayout = findViewById(R.id.Linearrinbot);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        LISTAbatterie= new ArrayList<>();
        System.out.println(LISTAbatterie.toString());
        aa = new Spinner_Adapter(this,LISTAbatterie);

        nonrin.setOnItemSelectedListener(this);

        Controllospinner controllo= new Controllospinner();
        controllo.execute("");
    }
    public void RinbotteBtn(View view) {
        Send objSend = new Send();
        objSend.execute("");

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_MODBOTTE.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        str= (Spin_String)parent.getSelectedItem();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class Send extends AsyncTask<String, String, String> {
        String msg = "";
        int flag=0;
        Controllospinner control =new Controllospinner();
        String non_rinominata = str.toString();
        String rinominata = rin.getText().toString();
        List<String> listabotte = new ArrayList<String>(100);

        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                if (non_rinominata.isEmpty()) {
                    if (rinominata.isEmpty()) {
                        msg = "inserire i nomi delle botti...";
                        return msg;
                    }
                    msg = "inserire il nome di una botte...";
                    return msg;
                }
                if (rinominata.isEmpty()) {
                    msg = "inserire il nuovo nome...";
                    return msg;
                }
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else {
                    rinominata=rinominata.toLowerCase();
                    String UPDATE = "UPDATE tabella_botti SET nome_botte = '"+rinominata+"' where nome_botte='"+non_rinominata+"' and possessore='"+userino+"'";
                    String SELECT = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECT);

                    int n=0;
                    int i=0;
                    for(i=listabotte.size()-1;i>=0;i--) {
                        listabotte.remove(i);
                    }
                    while(rs.next()){
                        listabotte.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();
                    for(i=0;i<listabotte.size();i++){
                        if(rinominata.equals(listabotte.get(i))){
                            msg = "nome botte già utilizzato, inserire nome diverso";
                            return msg;
                        }
                        else if(non_rinominata.equals(listabotte.get(i))){
                            flag=1;
                        }
                    }
                    if(flag==1) {
                        stmt.executeUpdate(UPDATE);
                        msg = "Botte rinominata!";

                        return msg;
                    }
                }
                msg="Botte non trovata";
                conn.close();
            }
            catch (Exception e){
                int i=0;
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incaso.setText(msg);
            rin.setText("");
            Toast.makeText(MainActivity_RINBOTTE.this,msg, Toast.LENGTH_SHORT).show();
            control.execute("");
        }
    }

    public class Controllospinner extends AsyncTask<String, String, String> {
        String msg = "";
        List<String> listabatteria = new ArrayList<String>(100);
        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null) {
                    msg = "errore di connessione...";
                } else{
                    String SELECTbatterie = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"'";
                    System.out.println(SELECTbatterie);
                    Statement stmt = conn.createStatement();
                    ResultSet rs= stmt.executeQuery(SELECTbatterie);
                    int n=0;
                    int i=0;
                    for(i=listabatteria.size()-1;i>=0;i--) {
                        listabatteria.remove(i);
                    }
                    while(rs.next()){
                        listabatteria.add(n,rs.getString(2));
                        n++;
                    }
                    rs.close();
                    for(i=LISTAbatterie.size()-1;i>=0;i--){
                        System.out.println(Arrays.toString(LISTAbatterie.toArray()));
                        LISTAbatterie.remove(i);
                    }
                    for(i=0;i<listabatteria.size();i++){
                        Spin_String obj = new Spin_String(listabatteria.get(i));
                        LISTAbatterie.add(obj);
                    }
                }
                System.out.println(LISTAbatterie.toString());
                conn.close();
            }
            catch (Exception e){
                msg = "problemi di collegamento";
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            if(msg.equals("")){
                incaso.setText("in attesa...");
            }
            else{
                incaso.setText(msg);
            }
            nonrin.setAdapter(aa);
        }
    }

}