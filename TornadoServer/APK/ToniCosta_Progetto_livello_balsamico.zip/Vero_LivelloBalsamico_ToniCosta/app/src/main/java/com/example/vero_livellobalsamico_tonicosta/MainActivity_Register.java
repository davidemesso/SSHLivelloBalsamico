package com.example.vero_livellobalsamico_tonicosta;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_Register extends AppCompatActivity {
    TextView incaso;
    EditText usr, psw;
    AlertDialog.Builder alertBat,alertBot;
    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_register);
        incaso=(TextView) findViewById(R.id.nelcaso);
        usr= (EditText) findViewById(R.id.usernameREG);
        psw= (EditText) findViewById(R.id.passwordREG);

        ConstraintLayout constraintLayout= findViewById(R.id.ConstraintREGISTER);
        AnimationDrawable animationDrawableee= (AnimationDrawable) constraintLayout.getBackground();
        animationDrawableee.start();

        LinearLayout linearLayout = findViewById(R.id.Linearreg);
        AnimationDrawable animationDrawable= (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        alertBat= new AlertDialog.Builder(this);
        alertBat.setTitle("ATTENZIONE!");
        alertBat.setMessage("Una volta scelti username e password non potrai più modificarli! \ncontinuare?");
        alertBat.setPositiveButton("SÌ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Send objSend = new Send();
                objSend.execute("");
            }
        });
        alertBat.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        alertBot= new AlertDialog.Builder(this);
        alertBot.setTitle("ATTENZIONE!");
        alertBot.setMessage("nome utente già utilizzato, provare un nome diverso.");
        alertBot.setNeutralButton("OK!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                incaso.setText("");
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity.class);
            finish();
            startActivity(miaActivity);

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    public void RegisterBtn(View view) {
        alertBat.create().show();
    }

    private class Send extends AsyncTask<String, String, String> {
        String msg = "";
        String user = usr.getText().toString();
        String password = psw.getText().toString();
        int flag=0;
        List<String> listautenti = new ArrayList<String>(100);

        @Override
        protected void onPreExecute() {
            incaso.setText("Attendere...");
        }

        @Override
        protected String doInBackground(String... strings) {
            try {

                if (user.isEmpty()) {
                    msg = "please insert username";
                    return msg;
                }
                if (password.isEmpty()) {
                    msg = "please insert password";
                    return msg;
                }
                user=user.toLowerCase();
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                    if (conn == null) {
                        msg = "errore di connessione...";
                    } else {

                        String INSERT = "INSERT INTO tabella_accessi(utente,password) VALUES('" + user + "','" + password + "')";
                        String SELECT = "SELECT * FROM tabella_accessi";
                        Statement stmt = conn.createStatement();
                        ResultSet rs= stmt.executeQuery(SELECT);

                        int n=0;
                        int i=0;
                        for(i=listautenti.size()-1;i>=0;i--) {
                            listautenti.remove(i);
                        }
                        while(rs.next()){
                            listautenti.add(n,rs.getString(1));
                            n++;
                        }

                        stmt.executeUpdate(INSERT);
                        msg = "registrazione completata!";
                        int flagBatteria=1;
                        int flagBotte=1;
                        Intent pagina_indatabase = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
                        pagina_indatabase.putExtra("user",user);
                        pagina_indatabase.putExtra("flbat",flagBatteria);
                        pagina_indatabase.putExtra("flbot",flagBotte);
                        pagina_indatabase.putExtra("msg","Registrazione effettuata!");

                        startActivity(pagina_indatabase);

                        finish();
                    }
                conn.close();
                }
            catch (Exception e){
                int i=0;
                for(i=0;i<listautenti.size();i++){
                    if(user.equals(listautenti.get(i))){
                        flag=1;
                        return msg;
                    }
                }
                msg = "problemi di collegamento";
                }

                return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            incaso.setText(msg);
            if (flag==1){
                alertBot.create().show();
            }
        }
    }

}
