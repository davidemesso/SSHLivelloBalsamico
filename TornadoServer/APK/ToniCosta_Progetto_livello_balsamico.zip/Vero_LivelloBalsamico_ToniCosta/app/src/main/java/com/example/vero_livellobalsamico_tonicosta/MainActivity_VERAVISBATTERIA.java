package com.example.vero_livellobalsamico_tonicosta;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_VERAVISBATTERIA extends AppCompatActivity {
    Batteria_List_Adapter adapter;
    ListView listView;
    ArrayList<Batteria> batterialista = new ArrayList();
    int flagBatteria,flagBotte, FLAG;
    String userino;
    TextView incaso;
    String batteria;

    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main__veravisbatteri);
        listView = (ListView) findViewById(R.id.ListViewetta);
        incaso = (TextView) findViewById(R.id.controlloRINbotte);
        userino = getIntent().getExtras().getString("user");
        batteria = getIntent().getExtras().getString("bat");
        flagBatteria = getIntent().getExtras().getInt("flbat");
        flagBotte = getIntent().getExtras().getInt("flbot");
        FLAG = getIntent().getExtras().getInt("flag");

        Send objSend = new Send();
        objSend.execute("");

        adapter = new Batteria_List_Adapter(this, R.layout.adapter_view_layout_batteria,objSend.batterialistavera);
        listView.setAdapter(adapter);

    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if(FLAG==1) {
                Intent miaActivity = new Intent(getApplicationContext(), MainActivity_OTTMISURAZIONE.class);
                miaActivity.putExtra("user", userino);
                miaActivity.putExtra("flbot", flagBotte);
                miaActivity.putExtra("flbat", flagBatteria);

                startActivity(miaActivity);
                finish();
            }

            if(FLAG==2) {
                Intent miaActivity = new Intent(getApplicationContext(), MainActivity_RESMISURAZIONE.class);
                miaActivity.putExtra("user", userino);
                miaActivity.putExtra("flbot", flagBotte);
                miaActivity.putExtra("flbat", flagBatteria);

                startActivity(miaActivity);
                finish();
            }

            if(FLAG==3) {
                Intent miaActivity = new Intent(getApplicationContext(), MainActivity_VISBATTERIA.class);
                miaActivity.putExtra("user", userino);
                miaActivity.putExtra("flbot", flagBotte);
                miaActivity.putExtra("flbat", flagBatteria);

                startActivity(miaActivity);
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public class Send extends AsyncTask<String, String, ArrayList> {
        ArrayList<Batteria> batterialistavera = new ArrayList();
        List<String> listabatterie = new ArrayList<String>(100);
        List<String> listaID = new ArrayList<String>(100);
        List<String> listaDifferenza = new ArrayList<String>(100);
        List<String> listaData = new ArrayList<String>(100);
        String msg = "";
        int i = 0;
        @Override
        protected void onPreExecute() {
        }

        protected ArrayList doInBackground(String... Strings) {
            try {

                Class.forName("com.mysql.jdbc.Driver");

                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

                if (conn == null) {
                    System.out.println("errore di connessione");
                } else {
                    String SELECT = "SELECT * FROM tabella_botti WHERE possessore='"+userino+"' and id_batteria=(SELECT ID_batteria FROM tabella_batterie WHERE proprietario='" +userino+ "' AND nome_batteria='" +batteria+ "')";
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(SELECT);
                    System.out.println(SELECT);

                    int n = 0;
                    for (i = listabatterie.size() - 1; i >= 0; i--) {
                        listabatterie.remove(i);
                        listaDifferenza.remove(i);
                        listaID.remove(i);
                        listaData.remove(i);
                    }

                    while (rs.next()) {
                        listaID.add(n, rs.getString(1));
                        listabatterie.add(n, rs.getString(2));
                        listaDifferenza.add(n, rs.getString(5));
                        listaData.add(n, rs.getString(6));
                        n++;
                    }
                    rs.close();

                    conn.close();


                    for (i = 0; i < listaID.size(); i++) {
                        Batteria batteria = new Batteria(listaID.get(i), listabatterie.get(i), listaDifferenza.get(i), listaData.get(i));
                        batterialista.add(batteria);
                    }


                }

            } catch (Exception e) {
                System.out.println("problemi di collegamento");
            }
            return batterialista;
        }
        @Override
        protected void onPostExecute(ArrayList msg) {
            super.onPostExecute(msg);
            batterialistavera=msg;
            System.out.println(batterialistavera.toString());
            adapter.updateReceiptsList(batterialista);
        }
    }
}