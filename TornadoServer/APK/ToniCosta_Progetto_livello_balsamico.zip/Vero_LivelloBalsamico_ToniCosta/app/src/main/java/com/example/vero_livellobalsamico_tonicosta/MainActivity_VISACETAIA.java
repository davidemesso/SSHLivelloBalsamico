package com.example.vero_livellobalsamico_tonicosta;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity_VISACETAIA extends AppCompatActivity {
    Acetaia_List_Adapter adapter;
    ListView listView;
    ArrayList<Acetaia> acetaialista = new ArrayList();
    int flagBotte,flagBatteria;
    String userino;
    TextView incaso;
    int oddio=0;

    private static final String DB_URL = "jdbc:mysql://balsamico.toni.it/database_aceto";
    private static final String USER = "marcello";
    private static final String PASS = "PASSWORD database";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main__visacetai);
        ListView listView = (ListView) findViewById(R.id.ListView);
        incaso = (TextView) findViewById(R.id.controlloRINbotte);
        userino = getIntent().getExtras().getString("user");
        flagBatteria=getIntent().getExtras().getInt("flbat");
        flagBotte=getIntent().getExtras().getInt("flbot");

        Send objSend = new Send();
        objSend.execute("");
        System.out.println(objSend.acetaialistavera);

        adapter = new Acetaia_List_Adapter(this, R.layout.adapter_view_layout,objSend.acetaialistavera);
        listView.setAdapter(adapter);

        System.out.println(oddio);


    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent miaActivity = new Intent(getApplicationContext(), MainActivity_InDatabase.class);
            miaActivity.putExtra("user", userino);
            miaActivity.putExtra("flbot",flagBotte);
            miaActivity.putExtra("flbat",flagBatteria);
            miaActivity.putExtra("msg","");

            startActivity(miaActivity);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public class Send extends AsyncTask<String, String, ArrayList> {
        ArrayList<Acetaia> acetaialistavera = new ArrayList();
        List<String> listabatterie = new ArrayList<String>(100);
        List<String> listaID = new ArrayList<String>(100);
        String msg = "";
        int i = 0;
        @Override
        protected void onPreExecute() {
        }

        protected ArrayList doInBackground(String... Strings) {
            try {

                Class.forName("com.mysql.jdbc.Driver");

                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

                if (conn == null) {
                    System.out.println("errore di connessione");
                } else {
                    String SELECT = "SELECT * FROM tabella_batterie WHERE proprietario='" + userino + "'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(SELECT);


                    int n = 0;
                    for (i = listabatterie.size() - 1; i >= 0; i--) {
                        listabatterie.remove(i);
                    }
                    for (i = listaID.size() - 1; i >= 0; i--) {
                        listaID.remove(i);
                    }
                    while (rs.next()) {
                        listaID.add(n, rs.getString(1));
                        listabatterie.add(n, rs.getString(2));
                        n++;
                    }
                    rs.close();

                    conn.close();


                    for (i = 0; i < listaID.size(); i++) {
                        Acetaia acetaia = new Acetaia(listaID.get(i), listabatterie.get(i));
                        acetaialista.add(acetaia);
                    }


                }

            } catch (Exception e) {
                System.out.println("problemi di collegamento");
            }
            return acetaialista;
        }
        @Override
        protected void onPostExecute(ArrayList msg) {
            super.onPostExecute(msg);
            acetaialistavera=msg;
            System.out.println(acetaialistavera.toString());
            adapter.updateReceiptsList(acetaialista);
        }
    }
}

