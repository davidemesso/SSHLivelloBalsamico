package com.example.vero_livellobalsamico_tonicosta;

public class Spin_String {
    private String botte_batteria;

    public Spin_String(String botte_batteria) {
        this.botte_batteria = botte_batteria;
    }

    public String getBotte_batteria() {
        return botte_batteria;
    }

    public void setBotte_batteria(String botte_batteria) {
        this.botte_batteria = botte_batteria;
    }

    @Override
    public String toString() {
        return ""+botte_batteria;
    }
}
