package com.example.vero_livellobalsamico_tonicosta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Spinner_Adapter extends ArrayAdapter<Spin_String> {
    private static final String TAG= "Spin_Adapter";

    private Context mContext;
    ArrayList<Spin_String> mObject;


    public Spinner_Adapter(@NonNull Context context, @NonNull ArrayList<Spin_String> objects) {
        super(context, 0, objects);
        mContext = context;
        mObject= objects;
    }

    public void updateReceiptsList(ArrayList<Spin_String> newlist) {

        mObject.addAll(newlist);
        this.notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return CustomView(position,convertView,parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return CustomView(position, convertView, parent);
    }

    public View CustomView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        if(convertView==null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.spinner_layout, parent, false);
        }
        Spin_String obj_stringa=getItem(position);
        TextView spinText = convertView.findViewById(R.id.textviewSPINBOTTE);
        if (obj_stringa!=null){
            spinText.setText(obj_stringa.getBotte_batteria());
        }
        return convertView;
    }
}
